// Elan ePS6900 (RISC II) core: 16-bit instruction words, 8-bit ACC, 96K-word ROM.
// Written from the ePS6900 datasheet (V1.0 11.22.2010), sec. 7 and 12.  Portable C++17.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <string>
#include <vector>
#include <set>

namespace elan {

inline std::string fmt(const char* f, ...) {
    char b[200]; va_list ap; va_start(ap, f); vsnprintf(b, sizeof b, f, ap); va_end(ap); return b;
}

enum { R_INDF0 = 0, R_FSR0, R_BSR, R_INDF1, R_FSR1, R_BSR1, R_STKPTR, R_PCL, R_PCM, R_PCH, R_ACC, R_TBL, R_TBM, R_TBH,
       R_LCDDATA, R_STATUS, R_INDF2, R_FSR2, R_BSR2 };
enum { R_CPUCON = 0x20, R_POST_ID, R_LCDARL, R_LCDARH, R_INTSTA, R_TR0CON, R_TRL0L, R_TRL0H, R_T0CL, R_T0CH, R_TR1CON,
       R_TRL1, R_TR2WCON, R_TRL2, R_LCDCON, R_R2F, R_STBCON = 0x30, R_PORTA, R_PACON, R_DCRA, R_PAWAKE, R_PAINTEN,
       R_PAINTSTA, R_PORTB, R_PBCON, R_DCRB, R_PORTC, R_PCCON, R_DCRC, R_PORTD, R_PORTE, R_DCRDE };
enum : uint8_t { F_C = 1, F_DC = 2, F_Z = 4, F_OV = 8, F_SLE = 16, F_SGE = 32, F_PD = 64, F_TO = 128 };

static const char* const REGNAME[0x40] = {
    "INDF0", "FSR0", "BSR", "INDF1", "FSR1", "BSR1", "STKPTR", "PCL", "PCM", "PCH", "ACC", "TABPTRL", "TABPTRM", "TABPTRH", "LCDDATA", "STATUS",
    "INDF2", "FSR2", "BSR2", "R13", "R14", "R15", "R16", "R17", "R18", "R19", "R1A", "R1B", "R1C", "R1D", "R1E", "R1F",
    "CPUCON", "POST_ID", "LCDARL", "LCDARH", "INTSTA", "TR0CON", "TRL0L", "TRL0H", "T0CL", "T0CH", "TR1CON", "TRL1", "TR2WCON", "TRL2", "LCDCON", "R2F",
    "STBCON", "PORTA", "PACON", "DCRA", "PAWAKE", "PAINTEN", "PAINTSTA", "PORTB", "PBCON", "DCRB", "PORTC", "PCCON", "DCRC", "PORTD", "PORTE", "DCRDE" };

inline std::string regname(int r) { return (r < 0x40 && REGNAME[r][0] != 'R') ? std::string(REGNAME[r]) : fmt("R%02X", r); }

// ---------------------------------------------------------------- disassembler
struct Insn { std::string text; int len; };
inline Insn disasm(const uint16_t* rom, uint32_t pc) {
    uint16_t op = rom[pc], w2 = rom[pc + 1]; int hi = op >> 8, lo = op & 255; int b = hi & 7;
    auto I = [&](std::string s, int len = 1) { return Insn{ s, len }; };
    auto R = [&](int r) { return regname(r); };
    if (op == 0) return I("NOP");
    if (op == 1) return I("WDTC");
    if (op == 2) return I("SLEP");
    if ((op & 0xfffe) == 0x0020) return I(fmt("LJMP %05X", ((op & 1) << 16) | w2), 2);
    if ((op & 0xfffe) == 0x0030) return I(fmt("LCALL %05X", ((op & 1) << 16) | w2), 2);
    if (op == 0x2bfe) return I("RET");
    if (op == 0x2bff) return I("RETI");
    if ((op & 0xf000) == 0x3000) return I(fmt("S0CALL %03X", op & 0xfff));
    if ((op & 0xe000) == 0xe000) return I(fmt("SCALL %04X", op & 0x1fff));
    if ((op & 0xe000) == 0xc000) return I(fmt("SJMP %04X", op & 0x1fff));
    if ((op & 0xe000) == 0x8000) return I(fmt("MOVRP %s,%s", R((op >> 8) & 31).c_str(), R(lo).c_str()));
    if ((op & 0xe000) == 0xa000) return I(fmt("MOVPR %s,%s", R(lo).c_str(), R((op >> 8) & 31).c_str()));
    switch (hi) {
    case 0x01: return I("SFR4 " + R(lo));  case 0x02: return I("OR A," + R(lo));   case 0x03: return I("OR " + R(lo) + ",A");
    case 0x04: return I("AND A," + R(lo)); case 0x05: return I("AND " + R(lo) + ",A"); case 0x06: return I("XOR A," + R(lo)); case 0x07: return I("XOR " + R(lo) + ",A");
    case 0x08: return I("COMA " + R(lo));  case 0x09: return I("COM " + R(lo));    case 0x0a: return I("RRCA " + R(lo)); case 0x0b: return I("RRC " + R(lo));
    case 0x0c: return I("RLCA " + R(lo));  case 0x0d: return I("RLC " + R(lo));    case 0x0e: return I("SWAPA " + R(lo)); case 0x0f: return I("SWAP " + R(lo));
    case 0x10: return I("ADD A," + R(lo)); case 0x11: return I("ADD " + R(lo) + ",A"); case 0x12: return I("ADC A," + R(lo)); case 0x13: return I("ADC " + R(lo) + ",A");
    case 0x14: return I("ADDDC A," + R(lo)); case 0x15: return I("ADDDC " + R(lo) + ",A"); case 0x16: return I("SUB A," + R(lo)); case 0x17: return I("SUB " + R(lo) + ",A");
    case 0x18: return I("SUBB A," + R(lo)); case 0x19: return I("SUBB " + R(lo) + ",A"); case 0x1a: return I("SUBDB A," + R(lo)); case 0x1b: return I("SUBDB " + R(lo) + ",A");
    case 0x1c: return I("INCA " + R(lo)); case 0x1d: return I("INC " + R(lo)); case 0x1e: return I("DECA " + R(lo)); case 0x1f: return I("DEC " + R(lo));
    case 0x20: return I("MOV A," + R(lo)); case 0x21: return I("MOV " + R(lo) + ",A"); case 0x22: return I("SHRA " + R(lo)); case 0x23: return I("SHLA " + R(lo));
    case 0x24: return I("CLR " + R(lo));   case 0x25: return I("TEST " + R(lo));   case 0x26: return I("MOVL " + R(lo) + ",A"); case 0x27: return I("RPT " + R(lo));
    case 0x28: return I("MOVH " + R(lo) + ",A"); case 0x29: return I("MOVL A," + R(lo)); case 0x2a: return I("MOVH A," + R(lo));
    case 0x2c: case 0x2d: case 0x2e: return I(fmt("TBRD %d,%s", hi & 3, R(lo).c_str()), 1);
    case 0x2f: return I("TBRD A," + R(lo));
    case 0x40: return I(fmt("TBPTL #%02X", lo)); case 0x41: return I(fmt("TBPTM #%02X", lo)); case 0x42: return I(fmt("TBPTH #%02X", lo)); case 0x43: return I(fmt("BANK #%02X", lo));
    case 0x44: return I(fmt("OR A,#%02X", lo)); case 0x45: return I(fmt("AND A,#%02X", lo)); case 0x46: return I(fmt("XOR A,#%02X", lo));
    case 0x47: return I(fmt("JGE A,#%02X,%04X", lo, w2), 2); case 0x48: return I(fmt("JLE A,#%02X,%04X", lo, w2), 2); case 0x49: return I(fmt("JE A,#%02X,%04X", lo, w2), 2);
    case 0x4a: return I(fmt("ADD A,#%02X", lo)); case 0x4b: return I(fmt("ADC A,#%02X", lo)); case 0x4c: return I(fmt("SUB A,#%02X", lo)); case 0x4d: return I(fmt("SUBB A,#%02X", lo));
    case 0x4e: return I(fmt("MOV A,#%02X", lo)); case 0x4f: return I("SFL4 " + R(lo));
    case 0x50: return I(fmt("JDNZ A,%s,%04X", R(lo).c_str(), w2), 2); case 0x51: return I(fmt("JDNZ %s,%04X", R(lo).c_str(), w2), 2);
    case 0x52: return I("EXL " + R(lo)); case 0x53: return I("EXH " + R(lo)); case 0x54: return I("EX " + R(lo));
    case 0x55: return I(fmt("JGE A,%s,%04X", R(lo).c_str(), w2), 2); case 0x56: return I(fmt("JLE A,%s,%04X", R(lo).c_str(), w2), 2); case 0x57: return I(fmt("JE A,%s,%04X", R(lo).c_str(), w2), 2);
    }
    if (hi >= 0x58 && hi <= 0x5f) return I(fmt("JBC %s,%d,%04X", R(lo).c_str(), b, w2), 2);
    if (hi >= 0x60 && hi <= 0x67) return I(fmt("JBS %s,%d,%04X", R(lo).c_str(), b, w2), 2);
    if (hi >= 0x68 && hi <= 0x6f) return I(fmt("BC %s,%d", R(lo).c_str(), b));
    if (hi >= 0x70 && hi <= 0x77) return I(fmt("BS %s,%d", R(lo).c_str(), b));
    if (hi >= 0x78 && hi <= 0x7f) return I(fmt("BTG %s,%d", R(lo).c_str(), b));
    return I(fmt("DW %04X ???", op));
}

// ---------------------------------------------------------------- CPU
struct Trace { uint64_t n; uint32_t pc; uint16_t op, w2; uint8_t a, st, bsr; };

struct Cpu {
    std::vector<uint16_t> rom;        // 98304 words (+ pad)
    std::vector<uint8_t> flash;       // external SPI flash image (viewer only)
    uint8_t gen[0x80];                // unbanked 00-7F storage for general RAM (control regs are handled separately)
    uint8_t gen24[0x20];              // 24h-3Fh general RAM when WBK=1
    uint8_t ctl[0x40];                // control/SFR storage 00-3F
    uint8_t bank[64][128];
    uint8_t lcd[4][128];              // LCD RAM: page x column
    uint8_t keymat[32];               // pressed keys per strobe line -> PA bits (bit i = PAi pulled low)
    uint32_t pc = 0; uint8_t acc = 0;
    uint32_t stack[32]; uint8_t stkptr = 0;
    uint32_t tabptr = 0;
    uint8_t status = F_TO | F_PD;
    uint64_t icount = 0, cycles = 0;
    bool halted = false, sleeping = false; std::string halt_msg;
    int rpt = 0; bool rpt_on = false;
    int pend_inc[3] = { 0, 0, 0 };    // FSRn post inc/dec pending after current instruction
    uint8_t cur_bank_override = 0xff;
    double t_acc[3] = { 0, 0, 0 };
    std::vector<Trace> trace; size_t trace_head = 0; bool trace_on = true;
    struct IoEv { uint8_t reg; uint8_t val; bool wr; uint32_t pc; };
    std::vector<IoEv> iolog; size_t iolog_head = 0;

    Cpu() : rom(0x18000 + 4, 0), trace(8192), iolog(256) { reset(); }

    // ---- register file
    bool wbk() const { return ctl[R_CPUCON] & 0x80; }
    uint8_t bsr() const { return ctl[R_BSR] & 0x3f; }
    uint8_t* ram_ptr(uint8_t r, uint8_t bsrv) {
        if (r >= 0x80) return &bank[bsrv & 0x3f][r - 0x80];
        if (r >= 0x40) return &gen[r];
        if (r >= 0x24 && wbk()) return &gen24[r - 0x24];
        if (r >= 0x13 && r < 0x20) return &gen[r];
        return nullptr;
    }
    uint8_t lcd_addr_page() const { return ctl[R_LCDARH] & 3; }

    uint8_t read_portA() const {
        uint8_t v = 0xff;
        uint8_t b = ctl[R_PORTB], c = ctl[R_PORTC];
        for (int i = 0; i < 8; i++) if (!(b & (1 << i)) && !(ctl[R_DCRB] & (1 << i))) v &= ~keymat[i];
        for (int i = 0; i < 4; i++) if (!(c & (1 << i)) && !(ctl[R_DCRC] & (1 << i))) v &= ~keymat[8 + i];
        uint8_t sb = ctl[R_STBCON];
        if (sb & 0x20) {   // SEG0-15 as strobe
            if ((sb & 0x10) || (sb & 0x40)) for (int i = 0; i < 16; i++) v &= ~keymat[16 + i];
            else v &= ~keymat[16 + (sb & 15)];
        }
        return v;
    }

    uint8_t fsr_ptr_access(int n, bool write, uint8_t val, bool& ok) {   // INDF0/1/2
        static const uint8_t FSR[3] = { R_FSR0, R_FSR1, R_FSR2 }, BSRR[3] = { R_BSR, R_BSR1, R_BSR2 };
        uint8_t f = ctl[FSR[n]]; if (n) f |= 0x80; uint8_t bs = (n == 0) ? bsr() : (ctl[BSRR[n]] & 0x3f); ok = true;
        pend_inc[n] = 1;
        if (n == 0 && f < 0x40 && !(f >= 0x13 && f < 0x20)) {            // special registers through INDF0
            if (f == R_INDF0 || f == R_INDF1 || f == R_INDF2) return 0;
            if (write) { wr(f, val); return val; } return rd(f);
        }
        uint8_t* p = ram_ptr(f, bs); static uint8_t dummy; if (!p) { dummy = 0; p = &dummy; }
        if (write) *p = val;
        return *p;
    }

    uint8_t rd(uint8_t r, bool indirect_ok = false) {
        (void)indirect_ok;
        switch (r) {
        case R_INDF0: { bool ok; return fsr_ptr_access(0, false, 0, ok); }
        case R_INDF1: { bool ok; return fsr_ptr_access(1, false, 0, ok); }
        case R_INDF2: { bool ok; return fsr_ptr_access(2, false, 0, ok); }
        case R_FSR1: case R_FSR2: return ctl[r] | 0x80;
        case R_BSR: case R_BSR1: case R_BSR2: return ctl[r] & 0x3f;
        case R_STKPTR: return stkptr;
        case R_PCL: return pc & 0xff;
        case R_PCM: return (pc >> 8) & 0xff;
        case R_PCH: return (pc >> 16) & 1;
        case R_ACC: return acc;
        case R_TBL: return tabptr & 0xff; case R_TBM: return (tabptr >> 8) & 0xff; case R_TBH: return (tabptr >> 16) & 3;
        case R_LCDDATA: { uint8_t v = lcd[lcd_addr_page()][ctl[R_LCDARL] & 0x7f]; lcd_post(); return v; }
        case R_STATUS: return status;
        }
        if (r < 0x13) return ctl[r];
        if (r >= 0x13 && r < 0x20) return gen[r];
        if (r >= 0x24 && r < 0x40 && wbk()) return gen24[r - 0x24];
        if (r == R_PORTA) { uint8_t v = read_portA(); iolog_add(r, v, false); return v; }
        if (r < 0x40) { iolog_add(r, ctl[r], false); return ctl[r]; }
        if (r < 0x80) return gen[r];
        return bank[bsr()][r - 0x80];
    }
    void lcd_post() {
        if (!(ctl[R_POST_ID] & 0x04)) return;          // LCDPE
        if (ctl[R_POST_ID] & 0x40) ctl[R_LCDARL]++; else ctl[R_LCDARL]--;
    }
    void iolog_add(uint8_t r, uint8_t v, bool w) { iolog[iolog_head] = { r, v, w, pc }; iolog_head = (iolog_head + 1) % iolog.size(); }

    void wr(uint8_t r, uint8_t v, bool indirect_ok = false) {
        (void)indirect_ok;
        switch (r) {
        case R_INDF0: { bool ok; fsr_ptr_access(0, true, v, ok); return; }
        case R_INDF1: { bool ok; fsr_ptr_access(1, true, v, ok); return; }
        case R_INDF2: { bool ok; fsr_ptr_access(2, true, v, ok); return; }
        case R_STKPTR: stkptr = v; return;
        case R_PCL: pc = (pc & ~0xffu) | v; return;
        case R_PCM: pc = (pc & ~0xff00u) | (v << 8); return;
        case R_PCH: pc = (pc & 0xffffu) | ((v & 1) << 16); return;
        case R_ACC: acc = v; return;
        case R_TBL: tabptr = (tabptr & ~0xffu) | v; return;
        case R_TBM: tabptr = (tabptr & ~0xff00u) | (v << 8); return;
        case R_TBH: tabptr = (tabptr & 0xffffu) | ((v & 3) << 16); return;
        case R_LCDDATA: lcd[lcd_addr_page()][ctl[R_LCDARL] & 0x7f] = v; lcd_post(); return;
        case R_STATUS: status = v; return;
        }
        if (r < 0x13) { ctl[r] = v; return; }
        if (r >= 0x13 && r < 0x20) { gen[r] = v; return; }
        if (r >= 0x24 && r < 0x40 && wbk()) { gen24[r - 0x24] = v; return; }
        if (r < 0x40) {
            iolog_add(r, v, true);
            if (r == R_INTSTA || r == R_PAINTSTA) { ctl[r] = v; return; }
            ctl[r] = v; return;
        }
        if (r < 0x80) { gen[r] = v; return; }
        bank[bsr()][r - 0x80] = v;
    }

    // ---- flags / alu
    void setZ(uint8_t v) { status = (status & ~F_Z) | (v == 0 ? F_Z : 0); }
    uint8_t add8(uint8_t a, uint8_t b, int c, bool flags = true) {
        int s = a + b + c; uint8_t r = s & 0xff;
        if (flags) {
            int dc = ((a & 15) + (b & 15) + c) > 15; int c7 = ((a & 127) + (b & 127) + c) > 127; int c8 = s > 255;
            status &= ~(F_C | F_DC | F_Z | F_OV | F_SLE | F_SGE);
            status |= (c8 ? F_C : 0) | (dc ? F_DC : 0) | (r == 0 ? F_Z : 0) | ((c7 != c8) ? F_OV : 0) | ((int8_t)r <= 0 ? F_SLE : 0) | ((int8_t)r >= 0 ? F_SGE : 0);
        }
        return r;
    }
    uint8_t sub8(uint8_t m, uint8_t s, int c) {   // m - s - (1-c)
        return add8(m, (uint8_t)~s, c);
    }
    uint8_t bcd_add(uint8_t a, uint8_t b, int c) {
        int lo = (a & 15) + (b & 15) + c, dc = 0; if (lo > 9) { lo += 6; dc = 1; }
        int hi = (a >> 4) + (b >> 4) + (lo > 15 ? 1 : 0); lo &= 15; int cy = 0; if (hi > 9) { hi += 6; cy = 1; } hi &= 15;
        uint8_t r = (hi << 4) | lo; status &= ~(F_C | F_DC | F_Z); status |= (cy ? F_C : 0) | (dc ? F_DC : 0) | (r == 0 ? F_Z : 0); return r;
    }
    uint8_t bcd_sub(uint8_t m, uint8_t s, int c) {
        int bl = 1 - c; int lo = (m & 15) - (s & 15) - bl, b1 = 0; if (lo < 0) { lo += 10; b1 = 1; }
        int hi = (m >> 4) - (s >> 4) - b1, b2 = 0; if (hi < 0) { hi += 10; b2 = 1; } lo &= 15; hi &= 15;
        uint8_t r = (hi << 4) | lo; status &= ~(F_C | F_DC | F_Z); status |= (b2 ? 0 : F_C) | (b1 ? 0 : F_DC) | (r == 0 ? F_Z : 0); return r;
    }

    // ---- stack / control flow
    void push(uint32_t ret) { stkptr = (stkptr - 2) & 0xff; stack[(stkptr >> 1) & 31] = ret; }
    uint32_t pop() { uint32_t v = stack[(stkptr >> 1) & 31]; stkptr = (stkptr + 2) & 0xff; return v; }

    void reset() {
        memset(gen, 0, sizeof gen); memset(gen24, 0, sizeof gen24); memset(ctl, 0, sizeof ctl); memset(bank, 0, sizeof bank); memset(lcd, 0, sizeof lcd);
        memset(keymat, 0, sizeof keymat); memset(stack, 0, sizeof stack);
        ctl[R_PORTA] = 0xff; ctl[R_PORTB] = 0xff; ctl[R_PORTC] = 0x0f; ctl[R_DCRA] = 0xff; ctl[R_DCRB] = 0xff; ctl[R_DCRC] = 0x0f;
        pc = 0; acc = 0; stkptr = 0; tabptr = 0; status = F_TO | F_PD; icount = cycles = 0; halted = sleeping = false; halt_msg.clear(); rpt = 0; rpt_on = false;
        trace_head = 0; for (auto& t : trace) t.n = 0; t_acc[0] = t_acc[1] = t_acc[2] = 0;
    }
    void halt(const std::string& m) { halted = true; halt_msg = m; }

    void post_inc_apply() {
        static const uint8_t FSR[3] = { R_FSR0, R_FSR1, R_FSR2 }, BSRR[3] = { R_BSR, R_BSR1, R_BSR2 };
        for (int n = 0; n < 3; n++) if (pend_inc[n]) {
            pend_inc[n] = 0;
            uint8_t post = ctl[R_POST_ID]; int pe = (n == 0) ? (post & 1) : (n == 1 ? (post & 2) : (post & 8)); if (!pe) continue;
            int up = (n == 0) ? (post & 0x10) : (n == 1 ? (post & 0x20) : (post & 0x80));
            if (n == 0) { ctl[R_FSR0] += up ? 1 : -1; }
            else {   // 7-bit linear with carry into BSRn
                int lin = ((ctl[BSRR[n]] & 0x3f) << 7) | (ctl[FSR[n]] & 0x7f); lin += up ? 1 : -1; lin &= 0x1fff;
                ctl[FSR[n]] = (lin & 0x7f) | 0x80; ctl[BSRR[n]] = (lin >> 7) & 0x3f;
            }
        }
    }

    uint8_t pa_int_prev = 0xff;
    bool irq_pending(uint32_t& vec) {
        if (!(ctl[R_CPUCON] & 4)) return false;
        if (ctl[R_PAINTSTA] & ctl[R_PAINTEN]) { vec = 2; return true; }
        uint8_t s = ctl[R_INTSTA];
        if (((s & 1) && (ctl[R_TR0CON] & 0x10)) || ((s & 2) && (ctl[R_TR1CON] & 0x10)) || ((s & 4) && (ctl[R_TR2WCON] & 0x08))) { vec = 8; return true; }
        return false;
    }
    void tick_peripherals(int cyc) {
        // coarse timer model (clock source selection is not modelled): 1 count per (2^(psr+1)) cycles
        uint8_t t0 = ctl[R_TR0CON];
        if (t0 & 0x08) { t_acc[0] += cyc / (double)(1 << ((t0 & 3) + 1));
            while (t_acc[0] >= 1) { t_acc[0] -= 1; uint16_t c = ctl[R_T0CL] | (ctl[R_T0CH] << 8); c++; if (!c) { c = ctl[R_TRL0L] | (ctl[R_TRL0H] << 8); ctl[R_INTSTA] |= 1; } ctl[R_T0CL] = c & 0xff; ctl[R_T0CH] = c >> 8; } }
        uint8_t t1 = ctl[R_TR1CON];
        if (t1 & 0x08) { t_acc[1] += cyc / (double)(1 << ((t1 & 3) + 1)); static uint8_t c1 = 0; while (t_acc[1] >= 1) { t_acc[1] -= 1; if (++c1 == 0) { c1 = ctl[R_TRL1]; ctl[R_INTSTA] |= 2; } } }
        uint8_t t2 = ctl[R_TR2WCON];
        if (t2 & 0x04) { t_acc[2] += cyc / (double)(1 << ((t2 & 3) + 1)); static uint8_t c2 = 0; while (t_acc[2] >= 1) { t_acc[2] -= 1; if (++c2 == 0) { c2 = ctl[R_TRL2]; ctl[R_INTSTA] |= 4; } } }
        // PortA key falling edge -> PAINTSTA
        uint8_t pa = read_portA(); uint8_t fall = pa_int_prev & ~pa;
        if (fall & ctl[R_PAINTEN]) ctl[R_PAINTSTA] |= fall & ctl[R_PAINTEN];
        pa_int_prev = pa;
    }

    void jump16(uint16_t a) { pc = (pc & 0x10000u) | a; }

    void step() {
        if (halted) return;
        if (sleeping) {
            uint32_t v; tick_peripherals(8); cycles += 8;
            if ((ctl[R_PAINTSTA] & ctl[R_PAINTEN]) || irq_pending(v) || (ctl[R_PAINTSTA] & ctl[R_PAWAKE])) sleeping = false; else return;
        }
        { uint32_t vec; if (irq_pending(vec)) { ctl[R_CPUCON] &= ~4; push(pc); pc = vec; } }
        uint32_t pc0 = pc; if (pc0 >= 0x18000) { halt(fmt("PC out of ROM range: %05X", pc0)); return; }
        uint16_t op = rom[pc0], w2 = rom[pc0 + 1];
        if (trace_on) { Trace& t = trace[trace_head]; trace_head = (trace_head + 1) % trace.size(); t.n = icount + 1; t.pc = pc0; t.op = op; t.w2 = w2; t.a = acc; t.st = status; t.bsr = bsr(); }
        pc = pc0 + 1;
        int cyc = 1;
        int reps = 1; if (rpt_on) { reps = rpt; rpt_on = false; }
        int hi = op >> 8, lo = op & 255, b = hi & 7;
        for (int rep = 0; rep < reps; rep++) { pc = pc0 + 1; cyc = exec(op, w2, hi, lo, b); if (halted) return; post_inc_apply(); tick_peripherals(cyc); cycles += cyc; if (hi == 0x27) break; }
        if (reps == 0) { /* RPT 0: skip the instruction */ int l = disasm(rom.data(), pc0).len; pc = pc0 + l; }
        icount++;
    }

    int exec(uint16_t op, uint16_t w2, int hi, int lo, int b) {
        auto Z = [&](uint8_t v) { setZ(v); };
        if (op == 0) return 1;
        if (op == 1) { status |= F_TO | F_PD; return 1; }
        if (op == 2) { sleeping = true; status &= ~F_PD; return 1; }
        if ((op & 0xfffe) == 0x0020) { pc = ((op & 1) << 16) | w2; return 2; }
        if ((op & 0xfffe) == 0x0030) { push(pc + 1); pc = ((op & 1) << 16) | w2; return 2; }
        if (op == 0x2bfe) { pc = pop(); return 2; }
        if (op == 0x2bff) { pc = pop(); ctl[R_CPUCON] |= 4; return 2; }
        if ((op & 0xf000) == 0x3000) { push(pc); pc = op & 0xfff; return 2; }
        if ((op & 0xe000) == 0xe000) { push(pc); pc = (pc & ~0x1fffu) | (op & 0x1fff); return 2; }
        if ((op & 0xe000) == 0xc000) { pc = (pc & ~0x1fffu) | (op & 0x1fff); return 2; }
        if ((op & 0xe000) == 0x8000) { wr((op >> 8) & 31, rd(lo)); return 1; }
        if ((op & 0xe000) == 0xa000) { wr(lo, rd((op >> 8) & 31)); return 1; }
        uint8_t v;
        switch (hi) {
        case 0x01: { uint8_t r = rd(lo); uint8_t nr = ((acc & 15) << 4) | (r >> 4); acc = (acc & 0xf0) | (r & 15); wr(lo, nr); return 1; }
        case 0x02: acc |= rd(lo); Z(acc); return 1;           case 0x03: v = rd(lo) | acc; wr(lo, v); Z(v); return 1;
        case 0x04: acc &= rd(lo); Z(acc); return 1;           case 0x05: v = rd(lo) & acc; wr(lo, v); Z(v); return 1;
        case 0x06: acc ^= rd(lo); Z(acc); return 1;           case 0x07: v = rd(lo) ^ acc; wr(lo, v); Z(v); return 1;
        case 0x08: acc = ~rd(lo); Z(acc); return 1;           case 0x09: v = ~rd(lo); wr(lo, v); Z(v); return 1;
        case 0x0a: { uint8_t r = rd(lo); int c = status & F_C; acc = (r >> 1) | (c << 7); status = (status & ~F_C) | (r & 1); return 1; }
        case 0x0b: { uint8_t r = rd(lo); int c = status & F_C; v = (r >> 1) | (c << 7); status = (status & ~F_C) | (r & 1); wr(lo, v); return 1; }
        case 0x0c: { uint8_t r = rd(lo); int c = status & F_C; acc = (r << 1) | c; status = (status & ~F_C) | (r >> 7); return 1; }
        case 0x0d: { uint8_t r = rd(lo); int c = status & F_C; v = (r << 1) | c; status = (status & ~F_C) | (r >> 7); wr(lo, v); return 1; }
        case 0x0e: { uint8_t r = rd(lo); acc = (r << 4) | (r >> 4); return 1; }
        case 0x0f: { uint8_t r = rd(lo); wr(lo, (r << 4) | (r >> 4)); return 1; }
        case 0x10: acc = add8(acc, rd(lo), 0); return 1;
        case 0x11: { uint8_t r = rd(lo); v = add8(r, acc, 0); if (lo == R_PCL) { pc = pc + acc; return 2; } wr(lo, v); return 1; }
        case 0x12: acc = add8(acc, rd(lo), status & F_C); return 1;
        case 0x13: { uint8_t r = rd(lo); v = add8(r, acc, status & F_C); if (lo == R_PCL) { pc = pc + acc + (status & F_C ? 1 : 0); return 2; } wr(lo, v); return 1; }
        case 0x14: acc = bcd_add(acc, rd(lo), status & F_C); return 1;
        case 0x15: v = bcd_add(rd(lo), acc, status & F_C); wr(lo, v); return 1;
        case 0x16: acc = sub8(rd(lo), acc, 1); return 1;       case 0x17: v = sub8(rd(lo), acc, 1); wr(lo, v); return 1;
        case 0x18: acc = sub8(rd(lo), acc, status & F_C ? 1 : 0); return 1; case 0x19: v = sub8(rd(lo), acc, status & F_C ? 1 : 0); wr(lo, v); return 1;
        case 0x1a: acc = bcd_sub(rd(lo), acc, status & F_C ? 1 : 0); return 1; case 0x1b: v = bcd_sub(rd(lo), acc, status & F_C ? 1 : 0); wr(lo, v); return 1;
        case 0x1c: { uint8_t r = rd(lo); acc = r + 1; status = (status & ~(F_C | F_Z)) | (r == 0xff ? F_C : 0) | (acc == 0 ? F_Z : 0); return 1; }
        case 0x1d: { uint8_t r = rd(lo); v = r + 1; status = (status & ~(F_C | F_Z)) | (r == 0xff ? F_C : 0) | (v == 0 ? F_Z : 0); wr(lo, v); return 1; }
        case 0x1e: { uint8_t r = rd(lo); acc = r - 1; status = (status & ~(F_C | F_Z)) | (r != 0 ? F_C : 0) | (acc == 0 ? F_Z : 0); return 1; }
        case 0x1f: { uint8_t r = rd(lo); v = r - 1; status = (status & ~(F_C | F_Z)) | (r != 0 ? F_C : 0) | (v == 0 ? F_Z : 0); wr(lo, v); return 1; }
        case 0x20: acc = rd(lo); Z(acc); return 1;            case 0x21: wr(lo, acc); return 1;
        case 0x22: { uint8_t r = rd(lo); acc = (r >> 1) | ((status & F_C) << 7); return 1; }
        case 0x23: { uint8_t r = rd(lo); acc = (r << 1) | (status & F_C); return 1; }
        case 0x24: wr(lo, 0); setZ(0); return 1;              case 0x25: Z(rd(lo)); return 1;
        case 0x26: wr(lo, (rd(lo) & 0xf0) | (acc & 15)); return 1;
        case 0x27: rpt = rd(lo); rpt_on = true; return 1;
        case 0x28: wr(lo, (rd(lo) & 0x0f) | (acc << 4)); return 1;
        case 0x29: acc = rd(lo) & 15; return 1;               case 0x2a: acc = rd(lo) >> 4; return 1;
        case 0x2c: case 0x2d: case 0x2e: { int i = hi & 3; uint32_t w = (tabptr >> 1); uint16_t d = rom[w % rom.size()]; wr(lo, (tabptr & 1) ? d >> 8 : d & 0xff); if (i == 1) tabptr++; else if (i == 2) tabptr--; return 2; }
        case 0x2f: { uint32_t t = tabptr + acc; uint16_t d = rom[(t >> 1) % rom.size()]; wr(lo, (t & 1) ? d >> 8 : d & 0xff); return 2; }
        case 0x40: tabptr = (tabptr & ~0xffu) | lo; return 1;  case 0x41: tabptr = (tabptr & ~0xff00u) | (lo << 8); return 1;
        case 0x42: tabptr = (tabptr & 0xffffu) | ((lo & 3) << 16); return 1;
        case 0x43: ctl[R_BSR] = lo & 0x3f; return 1;
        case 0x44: acc |= lo; Z(acc); return 1;  case 0x45: acc &= lo; Z(acc); return 1;  case 0x46: acc ^= lo; Z(acc); return 1;
        case 0x47: if (acc >= lo) { jump16(w2); } else pc++; return 2;
        case 0x48: if (acc <= lo) { jump16(w2); } else pc++; return 2;
        case 0x49: if (acc == lo) { jump16(w2); } else pc++; return 2;
        case 0x4a: acc = add8(acc, lo, 0); return 1;  case 0x4b: acc = add8(acc, lo, status & F_C); return 1;
        case 0x4c: acc = sub8(lo, acc, 1); return 1;  case 0x4d: acc = sub8(lo, acc, status & F_C ? 1 : 0); return 1;
        case 0x4e: acc = lo; return 1;
        case 0x4f: { uint8_t r = rd(lo); uint8_t nr = (r << 4) | (acc & 15); acc = (acc & 0xf0) | (r >> 4); wr(lo, nr); return 1; }
        case 0x50: { acc = rd(lo) - 1; if (acc) jump16(w2); else pc++; return 2; }
        case 0x51: { v = rd(lo) - 1; wr(lo, v); if (v) jump16(w2); else pc++; return 2; }
        case 0x52: { uint8_t r = rd(lo); wr(lo, (r & 0xf0) | (acc & 15)); acc = (acc & 0xf0) | (r & 15); return 1; }
        case 0x53: { uint8_t r = rd(lo); wr(lo, (r & 0x0f) | (acc << 4)); acc = (acc & 0xf0) | (r >> 4); return 1; }
        case 0x54: { uint8_t r = rd(lo); wr(lo, acc); acc = r; return 1; }
        case 0x55: if (acc >= rd(lo)) jump16(w2); else pc++; return 2;
        case 0x56: if (acc <= rd(lo)) jump16(w2); else pc++; return 2;
        case 0x57: if (acc == rd(lo)) jump16(w2); else pc++; return 2;
        }
        if (hi >= 0x58 && hi <= 0x5f) { if (!((rd(lo) >> b) & 1)) jump16(w2); else pc++; return 2; }
        if (hi >= 0x60 && hi <= 0x67) { if ((rd(lo) >> b) & 1) jump16(w2); else pc++; return 2; }
        if (hi >= 0x68 && hi <= 0x6f) { wr(lo, rd(lo) & ~(1 << b)); return 1; }
        if (hi >= 0x70 && hi <= 0x77) { wr(lo, rd(lo) | (1 << b)); return 1; }
        if (hi >= 0x78 && hi <= 0x7f) { wr(lo, rd(lo) ^ (1 << b)); return 1; }
        halt(fmt("illegal opcode %04X at %05X", op, pc - 1));
        return 1;
    }
};

} // namespace elan
