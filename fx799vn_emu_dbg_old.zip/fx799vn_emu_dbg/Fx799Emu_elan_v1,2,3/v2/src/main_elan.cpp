// Flexio Fx799VN emulator / debugger  (u'nSP core, Win32 GUI, no external libs)
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <cstdio>
#include <cstdarg>
#include <cstdlib>
#include <string>
#include <vector>
#include <map>
#include <sstream>
#include <fstream>
#include <algorithm>
#include "elan.h"

using namespace elan;

// ------------------------------------------------------------ skin geometry (2400x5112 space)
struct SkinKey { const char* name; int x0, y0, x1, y1; };
static const SkinKey KEYS[] = {
#include "keys.inc"
};
static const int NKEYS = sizeof(KEYS) / sizeof(KEYS[0]);
static const int SKIN_W = 2400, SKIN_H = 5112;
static const int LCD_X0 = 279, LCD_Y0 = 1128, LCD_X1 = 2116, LCD_Y1 = 1878;

// ------------------------------------------------------------ emulator state
static Cpu g_cpu;
static bool g_running = false;
static std::set<uint32_t> g_bps;
static bool g_keys[64] = {};
static int g_keyS[64], g_keyP[64];       // matrix mapping (strobe line, PortA bit); -1 = unmapped
static std::map<std::string, int> g_keyIdx;
static std::string g_romInfo = "no ROM", g_flashInfo = "no flash";
static std::string g_dir;

// memory view: 0 RAM(bytes) 1 ROM(words) 2 FLASH(words) 3 LCD RAM(bytes)
static int g_memSpace = 0;
static uint32_t g_memBase = 0;
static int64_t g_sel = -1;
static std::string g_typed;
static uint32_t g_disTop = 0;
static std::vector<std::string> g_con;
static std::vector<std::string> g_hist; static size_t g_histPos = 0;

// ------------------------------------------------------------ UI globals
static HWND g_hwnd, g_edit, g_btn[6];
static HFONT g_font;
static int g_cw = 9, g_lh = 18;
static HDC g_skinDC; static HBITMAP g_skinBmp; static int g_skinBW = 0, g_skinBH = 0;
static WNDPROC g_oldEdit;
enum { ID_STEP = 1, ID_RUN, ID_RESET, ID_ROM, ID_FLASH, ID_HELP, ID_CMD = 20 };

struct Layout {
    int cw, ch, skinW, skinH; double s;
    int px, pw, colW, colA, colB, top, lines;
    int disN, trN, memN, conN;
    int disY, trY, memY, conY, editY;
} L;

static void Log(const char* f, ...) {
    char b[512]; va_list ap; va_start(ap, f); vsnprintf(b, sizeof b, f, ap); va_end(ap);
    g_con.push_back(b); if (g_con.size() > 200) g_con.erase(g_con.begin());
}

// ------------------------------------------------------------ helpers
static bool ReadFile(const std::string& path, std::vector<uint8_t>& out) {
    FILE* f = fopen(path.c_str(), "rb"); if (!f) return false;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    out.resize(n); size_t got = n ? fread(out.data(), 1, n, f) : 0; fclose(f); return got == (size_t)n;
}
static bool PickFile(char* out, const char* title) {
    OPENFILENAMEA o = {}; out[0] = 0;
    o.lStructSize = sizeof o; o.hwndOwner = g_hwnd; o.lpstrFile = out; o.nMaxFile = MAX_PATH; o.lpstrTitle = title;
    o.lpstrFilter = "Binary (*.bin;*.epm;*.rom)\0*.bin;*.epm;*.rom\0All files\0*.*\0";
    o.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    return GetOpenFileNameA(&o);
}
static bool ParseHex(const std::string& s, uint32_t& v) {
    std::string t = s; if (t.size() > 2 && t[0] == '0' && (t[1] == 'x' || t[1] == 'X')) t = t.substr(2);
    if (t.empty()) return false;
    char* e; v = (uint32_t)strtoul(t.c_str(), &e, 16); return *e == 0;
}
static uint16_t FlashWord(uint32_t w) {
    size_t o = (size_t)w * 2; if (o + 1 >= g_cpu.flash.size()) return 0xffff;
    return g_cpu.flash[o] | (g_cpu.flash[o + 1] << 8);
}
static uint8_t PeekReg(uint32_t a) {   // linear RAM view: 00-7F unbanked, then banks of 128
    Cpu& c = g_cpu;
    if (a >= 0x80) { uint32_t b = (a - 0x80) / 0x80; return b < 64 ? c.bank[b][(a - 0x80) % 0x80] : 0; }
    switch (a) {
    case R_PCL: return c.pc & 0xff; case R_PCM: return (c.pc >> 8) & 0xff; case R_PCH: return (c.pc >> 16) & 1;
    case R_ACC: return c.acc; case R_STATUS: return c.status; case R_STKPTR: return c.stkptr;
    case R_TBL: return c.tabptr & 0xff; case R_TBM: return (c.tabptr >> 8) & 0xff; case R_TBH: return (c.tabptr >> 16) & 3; }
    if (a < 0x13) return c.ctl[a];
    if (a < 0x20) return c.gen[a];
    if (a >= 0x24 && a < 0x40 && c.wbk()) return c.gen24[a - 0x24];
    if (a < 0x40) return c.ctl[a];
    return c.gen[a];
}
static void PokeReg(uint32_t a, uint8_t v) {
    Cpu& c = g_cpu;
    if (a >= 0x80) { uint32_t b = (a - 0x80) / 0x80; if (b < 64) c.bank[b][(a - 0x80) % 0x80] = v; return; }
    if (a == R_INDF0 || a == R_INDF1 || a == R_INDF2 || a == R_LCDDATA) { c.ctl[a] = v; return; }
    c.wr((uint8_t)a, v);
}
static uint32_t MemCount() { return g_memSpace == 0 ? 0x2080 : g_memSpace == 3 ? 512 : g_memSpace == 1 ? 0x18000 : (uint32_t)(g_cpu.flash.size() / 2); }
static int MemBytes() { return (g_memSpace == 0 || g_memSpace == 3) ? 1 : 2; }
static uint32_t MemRead(uint32_t a) {
    switch (g_memSpace) { case 0: return PeekReg(a); case 1: return a < g_cpu.rom.size() ? g_cpu.rom[a] : 0; case 2: return FlashWord(a); default: return a < 512 ? g_cpu.lcd[a >> 7][a & 127] : 0; }
}
static void MemWrite(uint32_t a, uint32_t v) {
    switch (g_memSpace) {
    case 0: PokeReg(a, (uint8_t)v); break;
    case 1: if (a < g_cpu.rom.size()) g_cpu.rom[a] = (uint16_t)v; break;
    case 2: { size_t o = (size_t)a * 2; if (o + 1 < g_cpu.flash.size()) { g_cpu.flash[o] = v & 0xff; g_cpu.flash[o + 1] = (v >> 8) & 0xff; } break; }
    default: if (a < 512) g_cpu.lcd[a >> 7][a & 127] = (uint8_t)v;
    }
}

static void ApplyKeys() {
    memset(g_cpu.keymat, 0, sizeof g_cpu.keymat);
    for (int i = 0; i < NKEYS; i++) if (g_keys[i] && g_keyS[i] >= 0) g_cpu.keymat[g_keyS[i] & 31] |= 1 << (g_keyP[i] & 7);
}
static void SetKey(int i, bool down) {
    if (g_keys[i] == down) return; g_keys[i] = down; ApplyKeys();
    if (down && g_keyS[i] < 0 && !strcmp(KEYS[i].name, "ON")) { g_cpu.sleeping = false; g_cpu.ctl[R_PAINTSTA] |= 1; }   // fallback wake-up
}
static void LoadKeymap(const std::string& path) {
    std::ifstream f(path); std::string ln; int n = 0;
    while (std::getline(f, ln)) { std::istringstream is(ln); std::string nm; int s, p; if (!(is >> nm) || nm[0] == '#') continue;
        if (is >> s >> p) { auto it = g_keyIdx.find(nm); if (it != g_keyIdx.end()) { g_keyS[it->second] = s; g_keyP[it->second] = p; n++; } } }
    if (n) Log("keymap: %d keys mapped from %s", n, path.c_str());
}

static void LoadRom(const std::string& path) {
    std::vector<uint8_t> d; if (!ReadFile(path, d)) { Log("cannot read %s", path.c_str()); return; }
    std::fill(g_cpu.rom.begin(), g_cpu.rom.end(), 0);
    size_t words = std::min(d.size() / 2, g_cpu.rom.size());
    for (size_t i = 0; i < words; i++) g_cpu.rom[i] = d[2 * i] | (d[2 * i + 1] << 8);
    char b[300]; snprintf(b, sizeof b, "ROM %s (%zu words)", path.substr(path.find_last_of("\\/") + 1).c_str(), words);
    g_romInfo = b; g_cpu.reset(); g_running = false; g_disTop = 0; Log("%s loaded", b);
}
static void LoadFlash(const std::string& path) {
    if (!ReadFile(path, g_cpu.flash)) { Log("cannot read %s", path.c_str()); return; }
    char b[300]; snprintf(b, sizeof b, "FLASH %s (%zu bytes)", path.substr(path.find_last_of("\\/") + 1).c_str(), g_cpu.flash.size());
    g_flashInfo = b; Log("%s loaded (view: mf 0)", b);
}

// ------------------------------------------------------------ commands
static void Help() {
    Log("s [n] step | g run | p pause | r reset | bp [addr] toggle bp | bl | bc | pc <addr>");
    Log("m <addr> RAM bytes | mr <wordaddr> ROM | mf <wordoff> flash | ml LCD RAM | w <addr> <val> (current view)");
    Log("u <addr> disasm from | f <hex> find | rom <file> | flash <file> | trace on|off");
    Log("key <NAME> <strobe> <pabit> map key to matrix (strobe 0-7=PB0-7, 8-11=PC0-3, 16-31=SEG0-15)");
    Log("keys: F5 run/pause F6 reset F9 bp@PC F10 step | click hex cell, type hex, Enter");
}
static void Exec(std::string line) {
    std::istringstream is(line); std::vector<std::string> t; std::string w; while (is >> w) t.push_back(w);
    if (t.empty()) return;
    std::string c = t[0]; uint32_t a = 0, v = 0;
    Log("> %s", line.c_str());
    if (c == "help" || c == "?") Help();
    else if (c == "s") { uint32_t n = 1; if (t.size() > 1) ParseHex(t[1], n); g_running = false; for (uint32_t i = 0; i < n && !g_cpu.halted; i++) g_cpu.step(); if (g_cpu.halted) Log("HALT: %s", g_cpu.halt_msg.c_str()); }
    else if (c == "g") { if (g_cpu.halted) Log("CPU halted: %s (use r)", g_cpu.halt_msg.c_str()); else g_running = true; }
    else if (c == "p") g_running = false;
    else if (c == "r") { g_cpu.reset(); g_running = false; g_disTop = 0; Log("reset"); }
    else if (c == "bp") { a = g_cpu.pc; if (t.size() > 1 && !ParseHex(t[1], a)) { Log("bad addr"); return; } if (g_bps.count(a)) { g_bps.erase(a); Log("bp %05X removed", a); } else { g_bps.insert(a); Log("bp %05X set", a); } }
    else if (c == "bl") { for (auto b : g_bps) Log("bp %05X", b); if (g_bps.empty()) Log("(none)"); }
    else if (c == "bc") { g_bps.clear(); Log("breakpoints cleared"); }
    else if (c == "pc" && t.size() > 1 && ParseHex(t[1], a)) { a %= 0x18000; g_cpu.pc = a; g_disTop = a; g_cpu.halted = false; }
    else if (c == "u" && t.size() > 1 && ParseHex(t[1], a)) g_disTop = a % 0x17ff0;
    else if (c == "m" && t.size() > 1 && ParseHex(t[1], a)) { g_memSpace = 0; g_memBase = a & ~15u; g_sel = -1; }
    else if (c == "mr" && t.size() > 1 && ParseHex(t[1], a)) { g_memSpace = 1; g_memBase = a & ~7u; g_sel = -1; }
    else if (c == "mf" && t.size() > 1 && ParseHex(t[1], a)) { g_memSpace = 2; g_memBase = a & ~7u; g_sel = -1; }
    else if (c == "ml") { g_memSpace = 3; g_memBase = 0; g_sel = -1; }
    else if (c == "w" && t.size() > 2 && ParseHex(t[1], a) && ParseHex(t[2], v)) MemWrite(a, v);
    else if (c == "f" && t.size() > 1 && ParseHex(t[1], v)) {
        uint32_t lim = MemCount(), from = g_memBase + 1; bool found = false;
        for (uint32_t i = 0; i < lim; i++) { uint32_t p = (from + i) % lim; if (MemRead(p) == v) { g_memBase = p & ~(MemBytes() == 1 ? 15u : 7u); g_sel = p; Log("found at %05X", p); found = true; break; } }
        if (!found) Log("not found");
    }
    else if (c == "rom" && t.size() > 1) LoadRom(t[1]);
    else if (c == "flash" && t.size() > 1) LoadFlash(t[1]);
    else if (c == "trace" && t.size() > 1) { g_cpu.trace_on = (t[1] == "on"); Log("trace %s", g_cpu.trace_on ? "on" : "off"); }
    else if (c == "key" && t.size() > 3) {
        int s = atoi(t[2].c_str()), p = atoi(t[3].c_str()); auto it = g_keyIdx.find(t[1]);
        if (it == g_keyIdx.end()) Log("unknown key name"); else { g_keyS[it->second] = s; g_keyP[it->second] = p; Log("%s -> strobe %d PA%d", t[1].c_str(), s, p); }
    }
    else Log("unknown/invalid command (type help)");
}

// ------------------------------------------------------------ layout
static void DoLayout(int cw, int ch) {
    L.cw = cw; L.ch = ch;
    L.skinH = ch; L.skinW = (int)(ch * (double)SKIN_W / SKIN_H);
    if (L.skinW > cw * 38 / 100) { L.skinW = cw * 38 / 100; L.skinH = (int)(L.skinW * (double)SKIN_H / SKIN_W); }
    L.s = (double)L.skinW / SKIN_W;
    L.px = L.skinW + 10; L.pw = cw - L.px - 8; if (L.pw < 300) L.pw = 300;
    L.colW = (L.pw - 12) / 2; L.colA = L.px; L.colB = L.px + L.colW + 12;
    L.top = 44 + 5 * g_lh + 6;
    L.editY = ch - 30;
    int avail = (L.editY - L.top) / g_lh; int usable = std::max(8, avail - 2);
    L.disN = std::max(3, usable / 2); L.trN = std::max(3, usable - L.disN);
    L.memN = std::max(3, usable * 55 / 100); L.conN = std::max(3, usable - L.memN);
    L.disY = L.top + g_lh; L.trY = L.disY + L.disN * g_lh + g_lh;
    L.memY = L.top + g_lh; L.conY = L.memY + L.memN * g_lh + g_lh;
}
static void PlaceControls() {
    int x = L.px, y = 8, wds[6] = { 80, 100, 80, 100, 100, 60 };
    for (int i = 0; i < 6; i++) { MoveWindow(g_btn[i], x, y, wds[i], 28, TRUE); x += wds[i] + 6; }
    MoveWindow(g_edit, L.px, L.editY, L.pw, 24, TRUE);
}
// memory view geometry: cells per row and chars per cell
static int CellsPerRow() { return MemBytes() == 1 ? 16 : 8; }
static int CellChars() { return MemBytes() == 1 ? 3 : 5; }

// ------------------------------------------------------------ painting
static void T(HDC dc, int x, int y, COLORREF c, const char* f, ...) {
    char b[400]; va_list ap; va_start(ap, f); int n = vsnprintf(b, sizeof b, f, ap); va_end(ap);
    SetTextColor(dc, c); TextOutA(dc, x, y, b, n < 0 ? 0 : std::min(n, 399));
}
static const COLORREF C_BG = RGB(28, 28, 32), C_TX = RGB(215, 215, 215), C_HD = RGB(110, 170, 255), C_AD = RGB(140, 150, 160),
    C_PC = RGB(70, 66, 20), C_RED = RGB(255, 90, 90), C_GR = RGB(120, 220, 140), C_OR = RGB(255, 190, 90);

static void DrawLcd(HDC dc) {
    const int W = 192, H = 64; static uint32_t px[W * H];
    const uint32_t OFF = 0xE4E8EA, ON = 0x202830; const Cpu& c = g_cpu;
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
        bool bit = c.glcd_on && (c.gall || ((c.gram[y >> 3][x] >> (y & 7)) & 1)); if (c.grev && c.glcd_on) bit = !bit;
        px[y * W + x] = bit ? ON : OFF;
    }
    BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof bi.bmiHeader; bi.bmiHeader.biWidth = W; bi.bmiHeader.biHeight = -H;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    int x0 = (int)(LCD_X0 * L.s), y0 = (int)(LCD_Y0 * L.s), x1 = (int)(LCD_X1 * L.s), y1 = (int)(LCD_Y1 * L.s);
    SetStretchBltMode(dc, COLORONCOLOR);
    StretchDIBits(dc, x0, y0, x1 - x0, y1 - y0, 0, 0, W, H, px, &bi, DIB_RGB_COLORS, SRCCOPY);
}

static void Paint(HDC dc) {
    RECT cr; GetClientRect(g_hwnd, &cr); DoLayout(cr.right, cr.bottom);
    HBRUSH bg = CreateSolidBrush(C_BG); FillRect(dc, &cr, bg); DeleteObject(bg);
    SetStretchBltMode(dc, HALFTONE); SetBrushOrgEx(dc, 0, 0, nullptr);
    StretchBlt(dc, 0, 0, L.skinW, L.skinH, g_skinDC, 0, 0, g_skinBW, g_skinBH, SRCCOPY);
    DrawLcd(dc);
    for (int i = 0; i < NKEYS; i++) if (g_keys[i]) {
        RECT r = { (LONG)(KEYS[i].x0 * L.s), (LONG)(KEYS[i].y0 * L.s), (LONG)(KEYS[i].x1 * L.s), (LONG)(KEYS[i].y1 * L.s) };
        HBRUSH hb = CreateSolidBrush(RGB(255, 60, 60)); FrameRect(dc, &r, hb); InflateRect(&r, -1, -1); FrameRect(dc, &r, hb); DeleteObject(hb);
    }
    SelectObject(dc, g_font); SetBkMode(dc, TRANSPARENT);
    const int lh = g_lh, cw = g_cw; Cpu& c = g_cpu;
    int y = 44;
    COLORREF sc = c.halted ? C_RED : (c.sleeping ? C_OR : (g_running ? C_GR : C_OR));
    T(dc, L.px, y, sc, "[%s] instr=%llu cyc=%llu PC=%05X %s", c.halted ? "HALTED" : (c.sleeping ? "SLEEP" : (g_running ? "RUNNING" : "PAUSED")), (unsigned long long)c.icount, (unsigned long long)c.cycles, c.pc, c.halted ? c.halt_msg.c_str() : ""); y += lh;
    T(dc, L.px, y, C_TX, "A=%02X STATUS=%02X [%c%c%c%c%c%c] BSR=%02X STK=%02X CPUCON=%02X POST_ID=%02X", c.acc, c.status,
      (c.status & F_SGE) ? 'G' : '-', (c.status & F_SLE) ? 'L' : '-', (c.status & F_OV) ? 'V' : '-', (c.status & F_Z) ? 'Z' : '-', (c.status & F_DC) ? 'D' : '-', (c.status & F_C) ? 'C' : '-',
      c.ctl[R_BSR] & 0x3f, c.stkptr, c.ctl[R_CPUCON], c.ctl[R_POST_ID]); y += lh;
    T(dc, L.px, y, C_TX, "FSR0=%02X FSR1=%02X/%02X FSR2=%02X/%02X TABPTR=%05X LCDAR=%02X/%X LCDCON=%02X", c.ctl[R_FSR0], c.ctl[R_FSR1] | 0x80, c.ctl[R_BSR1] & 0x3f, c.ctl[R_FSR2] | 0x80, c.ctl[R_BSR2] & 0x3f, c.tabptr, c.ctl[R_LCDARL], c.ctl[R_LCDARH] & 3, c.ctl[R_LCDCON]); y += lh;
    T(dc, L.px, y, C_TX, "PB=%02X PC=%02X STBCON=%02X PAINTEN=%02X PAINTSTA=%02X INTSTA=%02X TR0=%02X", c.ctl[R_PORTB], c.ctl[R_PORTC], c.ctl[R_STBCON], c.ctl[R_PAINTEN], c.ctl[R_PAINTSTA], c.ctl[R_INTSTA], c.ctl[R_TR0CON]); y += lh;
    std::string kd; for (int i = 0; i < NKEYS; i++) if (g_keys[i]) { kd += KEYS[i].name; kd += ' '; }
    T(dc, L.px, y, C_AD, "%s | %s | keys: %s", g_romInfo.c_str(), g_flashInfo.c_str(), kd.c_str());

    // disassembly (word addresses)
    uint32_t pc = c.pc;
    if (g_disTop >= 0x17ff0) g_disTop = 0;
    { uint32_t a = g_disTop; bool vis = false; for (int n = 0; n < L.disN && a < 0x17ff0; n++) { if (a == pc) vis = true; a += disasm(c.rom.data(), a).len; } if (!vis) g_disTop = pc < 0x17ff0 ? pc : 0; }
    T(dc, L.colA, L.top, C_HD, "Disassembly  (click line = breakpoint)");
    { uint32_t a = g_disTop; for (int i = 0; i < L.disN && a < 0x17ff0; i++) {
        Insn in = disasm(c.rom.data(), a); int yy = L.disY + i * lh;
        if (a == pc) { RECT r = { L.colA - 2, yy, L.colA + L.colW, yy + lh }; HBRUSH hb = CreateSolidBrush(C_PC); FillRect(dc, &r, hb); DeleteObject(hb); }
        if (g_bps.count(a)) T(dc, L.colA, yy, C_RED, "*");
        char hx[24]; if (in.len == 2) snprintf(hx, sizeof hx, "%04X %04X", c.rom[a], c.rom[a + 1]); else snprintf(hx, sizeof hx, "%04X     ", c.rom[a]);
        T(dc, L.colA + cw, yy, C_AD, "%05X", a); T(dc, L.colA + cw * 7, yy, C_AD, "%s", hx); T(dc, L.colA + cw * 18, yy, a == pc ? RGB(255, 255, 160) : C_TX, "%s", in.text.c_str());
        a += in.len; } }
    // trace
    T(dc, L.colA, L.trY - lh, C_HD, "Executed instructions (newest at bottom)");
    { std::vector<const Trace*> v; size_t n = c.trace.size();
      for (size_t i = 0; i < n && (int)v.size() < L.trN; i++) { const Trace& t = c.trace[(c.trace_head + n - 1 - i) % n]; if (!t.n) break; v.push_back(&t); }
      std::reverse(v.begin(), v.end());
      for (size_t i = 0; i < v.size(); i++) { const Trace& t = *v[i]; Insn in = disasm(c.rom.data(), t.pc); int yy = L.trY + (int)i * lh;
        T(dc, L.colA, yy, C_AD, "%6llu %05X %04X", (unsigned long long)t.n, t.pc, t.op); T(dc, L.colA + cw * 19, yy, C_TX, "%-22s", in.text.c_str());
        T(dc, L.colA + cw * 42, yy, C_AD, "A=%02X S=%02X", t.a, t.st); } }
    // memory
    static const char* sn[4] = { "RAM bytes (00-7F, then banks)", "ROM words", "FLASH words", "LCD RAM (page*128+col)" };
    T(dc, L.colB, L.top, C_HD, "Memory [%s]  wheel scroll, click+type hex+Enter", sn[g_memSpace]);
    int cpr = CellsPerRow(), cc = CellChars(), bytes = MemBytes();
    for (int r = 0; r < L.memN; r++) {
        uint32_t base = g_memBase + r * cpr; int yy = L.memY + r * lh;
        T(dc, L.colB, yy, C_AD, "%05X:", base);
        for (int k = 0; k < cpr; k++) {
            uint32_t a = base + k; int xx = L.colB + cw * (7 + k * cc); bool sel = (g_sel == (int64_t)a);
            if (sel) { RECT rc = { xx - 2, yy, xx + cw * (cc - 1) + 2, yy + lh }; HBRUSH hb = CreateSolidBrush(RGB(60, 90, 160)); FillRect(dc, &rc, hb); DeleteObject(hb); }
            uint32_t v = MemRead(a);
            if (sel && !g_typed.empty()) T(dc, xx, yy, C_OR, "%*s", bytes * 2, g_typed.c_str());
            else T(dc, xx, yy, v ? C_TX : C_AD, bytes == 1 ? "%02X" : "%04X", v);
        }
    }
    T(dc, L.colB, L.conY - lh, C_HD, "Console   (type 'help')");
    { int n = (int)g_con.size(); int st = std::max(0, n - L.conN); for (int i = 0; i < L.conN; i++) { int idx = st + i; if (idx < n) T(dc, L.colB, L.conY + i * lh, C_TX, "%.*s", (int)(L.colW / cw) - 1, g_con[idx].c_str()); } }
}

// ------------------------------------------------------------ input
static int KeyAt(int mx, int my) {
    double sx = mx / L.s, sy = my / L.s; if (mx < 0 || mx > L.skinW || my < 0 || my > L.skinH) return -1;
    for (int i = 0; i < NKEYS; i++) if (sx >= KEYS[i].x0 && sx < KEYS[i].x1 && sy >= KEYS[i].y0 && sy < KEYS[i].y1) return i;
    return -1;
}
static int g_mouseKey = -1;

static int VkToKey(WPARAM vk) {
    const char* n = nullptr; char b[2] = { 0, 0 };
    if (vk >= '0' && vk <= '9') { b[0] = (char)vk; n = b; }
    else if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9) { b[0] = (char)('0' + vk - VK_NUMPAD0); n = b; }
    else switch (vk) {
        case VK_ADD: case VK_OEM_PLUS: n = "ADD"; break;
        case VK_SUBTRACT: case VK_OEM_MINUS: n = "SUB"; break;
        case VK_MULTIPLY: n = "MUL"; break;
        case VK_DIVIDE: case VK_OEM_2: n = "DIV"; break;
        case VK_DECIMAL: case VK_OEM_PERIOD: n = "DOT"; break;
        case VK_RETURN: n = "EQ"; break;
        case VK_BACK: n = "DEL"; break;
        case VK_ESCAPE: n = "AC"; break;
        case VK_UP: n = "UP"; break; case VK_DOWN: n = "DOWN"; break;
        case VK_LEFT: n = "LEFT"; break; case VK_RIGHT: n = "RIGHT"; break;
        case 'S': n = "SHIFT"; break; case 'A': n = "ALPHA"; break; case 'M': n = "MENU"; break; case 'O': n = "ON"; break;
        case VK_OEM_4: n = "LPAR"; break; case VK_OEM_6: n = "RPAR"; break;
        default: return -1;
    }
    auto it = g_keyIdx.find(n); return it == g_keyIdx.end() ? -1 : it->second;
}

static void ToggleBpAtPc() { uint32_t a = g_cpu.pc; if (g_bps.count(a)) g_bps.erase(a); else g_bps.insert(a); }
static void DoStep() { g_running = false; g_cpu.step(); if (g_cpu.halted) Log("HALT: %s", g_cpu.halt_msg.c_str()); }
static void DoRun() { if (g_cpu.halted) { Log("CPU halted: %s (reset first)", g_cpu.halt_msg.c_str()); return; } g_running = !g_running; }
static void DoReset() { g_cpu.reset(); g_running = false; g_disTop = 0; Log("reset"); }
static void CommitHex() {
    if (g_sel >= 0 && !g_typed.empty()) { uint32_t v; if (ParseHex(g_typed, v)) MemWrite((uint32_t)g_sel, v); }
    g_typed.clear(); if (g_sel >= 0) { g_sel++; if ((uint32_t)g_sel >= g_memBase + L.memN * CellsPerRow()) g_memBase += CellsPerRow(); }
}

static LRESULT CALLBACK EditProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (m == WM_CHAR && w == '\r') {
        char b[512]; GetWindowTextA(h, b, sizeof b); SetWindowTextA(h, "");
        if (b[0]) { g_hist.push_back(b); g_histPos = g_hist.size(); Exec(b); InvalidateRect(g_hwnd, nullptr, FALSE); }
        return 0;
    }
    if (m == WM_KEYDOWN && (w == VK_UP || w == VK_DOWN) && !g_hist.empty()) {
        if (w == VK_UP && g_histPos > 0) g_histPos--; else if (w == VK_DOWN && g_histPos + 1 < g_hist.size()) g_histPos++; else if (w == VK_DOWN) { g_histPos = g_hist.size(); SetWindowTextA(h, ""); return 0; }
        SetWindowTextA(h, g_hist[g_histPos].c_str()); SendMessage(h, EM_SETSEL, 4096, 4096); return 0;
    }
    return CallWindowProc(g_oldEdit, h, m, w, l);
}

static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CREATE: {
        const char* nm[6] = { "Step F10", "Run/Pause F5", "Reset F6", "Load ROM", "Load Flash", "Help" };
        for (int i = 0; i < 6; i++) g_btn[i] = CreateWindowA("BUTTON", nm[i], WS_CHILD | WS_VISIBLE, 0, 0, 10, 10, h, (HMENU)(INT_PTR)(ID_STEP + i), nullptr, nullptr);
        g_edit = CreateWindowExA(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 10, 10, h, (HMENU)ID_CMD, nullptr, nullptr);
        g_oldEdit = (WNDPROC)SetWindowLongPtr(g_edit, GWLP_WNDPROC, (LONG_PTR)EditProc);
        HFONT f = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
        for (int i = 0; i < 6; i++) SendMessage(g_btn[i], WM_SETFONT, (WPARAM)f, TRUE);
        SendMessage(g_edit, WM_SETFONT, (WPARAM)g_font, TRUE);
        SetTimer(h, 1, 15, nullptr);
        return 0;
    }
    case WM_SIZE: { DoLayout(LOWORD(l), HIWORD(l)); PlaceControls(); return 0; }
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: {
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); RECT cr; GetClientRect(h, &cr);
        HDC md = CreateCompatibleDC(dc); HBITMAP bm = CreateCompatibleBitmap(dc, cr.right, cr.bottom); HGDIOBJ old = SelectObject(md, bm);
        Paint(md); BitBlt(dc, 0, 0, cr.right, cr.bottom, md, 0, 0, SRCCOPY);
        SelectObject(md, old); DeleteObject(bm); DeleteDC(md); EndPaint(h, &ps); return 0;
    }
    case WM_TIMER:
        if (g_running && !g_cpu.halted) {
            for (int i = 0; i < 60000; i++) {
                g_cpu.step();
                if (g_cpu.halted) { g_running = false; Log("HALT: %s", g_cpu.halt_msg.c_str()); break; }
                if (!g_bps.empty() && g_bps.count(g_cpu.pc)) { g_running = false; Log("breakpoint at %05X", g_cpu.pc); break; }
            }
        }
        InvalidateRect(h, nullptr, FALSE); return 0;
    case WM_COMMAND:
        switch (LOWORD(w)) {
        case ID_STEP: DoStep(); break; case ID_RUN: DoRun(); break; case ID_RESET: DoReset(); break;
        case ID_ROM: { char p[MAX_PATH]; if (PickFile(p, "Program ROM image (Demo.epm / rom.bin)")) LoadRom(p); break; }
        case ID_FLASH: { char p[MAX_PATH]; if (PickFile(p, "SPI flash dump (mx25.bin)")) LoadFlash(p); break; }
        case ID_HELP: Help(); break;
        }
        SetFocus(h); InvalidateRect(h, nullptr, FALSE); return 0;
    case WM_LBUTTONDOWN: {
        int mx = (short)LOWORD(l), my = (short)HIWORD(l); SetFocus(h);
        int k = KeyAt(mx, my);
        if (k >= 0) { g_mouseKey = k; SetKey(k, true); g_sel = -1; g_typed.clear(); SetCapture(h); }
        else {
            // disassembly click -> breakpoint
            if (mx >= L.colA && mx < L.colA + L.colW && my >= L.disY && my < L.disY + L.disN * g_lh) {
                uint32_t a = g_disTop; int idx = (my - L.disY) / g_lh;
                for (int i = 0; i < idx && a < 0x17ff0; i++) a += disasm(g_cpu.rom.data(), a).len;
                if (g_bps.count(a)) g_bps.erase(a); else g_bps.insert(a);
            } else if (mx >= L.colB + g_cw * 7 && my >= L.memY && my < L.memY + L.memN * g_lh) {
                int col = (mx - (L.colB + g_cw * 7)) / (g_cw * CellChars()), row = (my - L.memY) / g_lh;
                if (col >= 0 && col < CellsPerRow()) { g_sel = g_memBase + row * CellsPerRow() + col; g_typed.clear(); }
            }
        }
        InvalidateRect(h, nullptr, FALSE); return 0;
    }
    case WM_LBUTTONUP:
        if (g_mouseKey >= 0) { SetKey(g_mouseKey, false); g_mouseKey = -1; ReleaseCapture(); InvalidateRect(h, nullptr, FALSE); }
        return 0;
    case WM_MOUSEWHEEL: {
        int d = GET_WHEEL_DELTA_WPARAM(w) / WHEEL_DELTA; POINT p = { (short)LOWORD(l), (short)HIWORD(l) }; ScreenToClient(h, &p);
        if (p.x >= L.colB) { int64_t nb = (int64_t)g_memBase - (int64_t)d * CellsPerRow() * 3; g_memBase = nb < 0 ? 0 : (uint32_t)nb; }
        InvalidateRect(h, nullptr, FALSE); return 0;
    }
    case WM_KEYDOWN: case WM_KEYUP: {
        bool down = (m == WM_KEYDOWN);
        if (down) {
            if (w == VK_PRIOR) { g_memBase = g_memBase >= (uint32_t)(L.memN * CellsPerRow()) ? g_memBase - L.memN * CellsPerRow() : 0; InvalidateRect(h, nullptr, FALSE); return 0; }
            if (w == VK_NEXT) { g_memBase += L.memN * CellsPerRow(); InvalidateRect(h, nullptr, FALSE); return 0; }
        }
        if (g_sel >= 0) {   // hex edit mode
            if (down && w == VK_ESCAPE) { g_typed.clear(); g_sel = -1; InvalidateRect(h, nullptr, FALSE); }
            if (down && w == VK_LEFT && g_sel > 0) { g_sel--; g_typed.clear(); InvalidateRect(h, nullptr, FALSE); }
            if (down && w == VK_RIGHT) { g_sel++; g_typed.clear(); InvalidateRect(h, nullptr, FALSE); }
            if (down && w == VK_UP && g_sel >= CellsPerRow()) { g_sel -= CellsPerRow(); g_typed.clear(); InvalidateRect(h, nullptr, FALSE); }
            if (down && w == VK_DOWN) { g_sel += CellsPerRow(); g_typed.clear(); InvalidateRect(h, nullptr, FALSE); }
            return 0;
        }
        int k = VkToKey(w);
        if (k >= 0) { SetKey(k, down); InvalidateRect(h, nullptr, FALSE); }
        return 0;
    }
    case WM_CHAR:
        if (g_sel >= 0) {
            if (w == '\r') { CommitHex(); }
            else if (w == 8) { if (!g_typed.empty()) g_typed.pop_back(); }
            else if (isxdigit((int)w) && (int)g_typed.size() < MemBytes() * 2) g_typed += (char)toupper((int)w);
            InvalidateRect(h, nullptr, FALSE);
        }
        return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProc(h, m, w, l);
}

static bool LoadSkin(HINSTANCE hi, HDC ref) {
    HRSRC r = FindResourceA(hi, MAKEINTRESOURCEA(101), RT_RCDATA); if (!r) return false;
    HGLOBAL g = LoadResource(hi, r); const uint8_t* d = (const uint8_t*)LockResource(g); if (!d) return false;
    const BITMAPFILEHEADER* fh = (const BITMAPFILEHEADER*)d; const BITMAPINFO* bi = (const BITMAPINFO*)(d + sizeof(BITMAPFILEHEADER));
    g_skinBW = bi->bmiHeader.biWidth; g_skinBH = abs(bi->bmiHeader.biHeight);
    g_skinBmp = CreateDIBitmap(ref, &bi->bmiHeader, CBM_INIT, d + fh->bfOffBits, bi, DIB_RGB_COLORS);
    g_skinDC = CreateCompatibleDC(ref); SelectObject(g_skinDC, g_skinBmp); return g_skinBmp != nullptr;
}

int WINAPI WinMain(HINSTANCE hi, HINSTANCE, LPSTR cmd, int show) {
    for (int i = 0; i < NKEYS; i++) { g_keyIdx[KEYS[i].name] = i; g_keyS[i] = i / 7; g_keyP[i] = i % 7; }   // placeholder matrix guess (PB0-7 x PA0-6); override with keymap.txt
    g_font = CreateFontA(-15, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH | FF_MODERN, "Consolas");
    HDC sdc = GetDC(nullptr); HGDIOBJ of = SelectObject(sdc, g_font); SIZE sz; GetTextExtentPoint32A(sdc, "0", 1, &sz); g_cw = sz.cx; g_lh = sz.cy + 2;
    SelectObject(sdc, of); LoadSkin(hi, sdc); ReleaseDC(nullptr, sdc);
    WNDCLASSA wc = {}; wc.lpfnWndProc = WndProc; wc.hInstance = hi; wc.lpszClassName = "Fx799Emu"; wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassA(&wc);
    g_hwnd = CreateWindowA("Fx799Emu", "Flexio Fx799VN - Elan ePS6900 emulator / debugger", WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, 1440, 860, nullptr, nullptr, hi, nullptr);
    Log("Fx799VN emulator (Elan ePS RISC II core). Put Demo.epm / rom.bin, flash.bin, keymap.txt, startup.txt next to the exe.");
    {   // auto-load next to the exe
        char ep[MAX_PATH]; GetModuleFileNameA(nullptr, ep, MAX_PATH); g_dir = ep; g_dir = g_dir.substr(0, g_dir.find_last_of("\\/") + 1);
        std::vector<uint8_t> probe;
        const char* roms[] = { "rom.bin", "Demo.epm", "rom.epm" };
        for (const char* r : roms) if (ReadFile(g_dir + r, probe)) { LoadRom(g_dir + r); break; }
        if (ReadFile(g_dir + "flash.bin", probe)) LoadFlash(g_dir + "flash.bin");
        LoadKeymap(g_dir + "keymap.txt");
        std::ifstream sf(g_dir + "startup.txt"); std::string ln; while (std::getline(sf, ln)) { if (!ln.empty() && ln[0] != '#') Exec(ln); }
    }
    if (cmd && cmd[0]) { std::string c = cmd; if (c.size() > 1 && c.front() == '"') c = c.substr(1, c.find('"', 1) - 1); std::istringstream cs(c); std::string one; while (std::getline(cs, one, ';')) Exec(one); }
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        if (msg.message == WM_KEYDOWN) {
            if (msg.wParam == VK_F5) { DoRun(); InvalidateRect(g_hwnd, nullptr, FALSE); continue; }
            if (msg.wParam == VK_F6) { DoReset(); InvalidateRect(g_hwnd, nullptr, FALSE); continue; }
            if (msg.wParam == VK_F9) { ToggleBpAtPc(); InvalidateRect(g_hwnd, nullptr, FALSE); continue; }
            if (msg.wParam == VK_F10) { DoStep(); InvalidateRect(g_hwnd, nullptr, FALSE); continue; }
        }
        TranslateMessage(&msg); DispatchMessage(&msg);
    }
    return 0;
}
