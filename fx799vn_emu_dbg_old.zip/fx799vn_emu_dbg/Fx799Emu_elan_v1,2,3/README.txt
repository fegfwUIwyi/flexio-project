Fx799Emu.exe - gia lap Flexio Fx799VN (loi Elan ePS6900 / RISC II) + debugger.
Tu dong nap cung thu muc: rom.bin hoac Demo.epm (ROM chuong trinh), flash.bin (SPI flash),
keymap.txt (ma tran phim), startup.txt (lenh khoi dong). Go 'help' trong console.
